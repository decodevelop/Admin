<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clientes extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
         'nombre_apellidos','email', /* 'dni', 'fecha_nacimiento',  'telefono',*/
    ];
	
	 /**
     * Get the post that owns the comment.
     */
    public function direcciones()
    {
        return $this->hasOne('App\Direcciones');
    }
}
