<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Direcciones extends Model
{
	
	 /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'cp', 'pais', 'estado', 'direccion', 'clientes_id', 'comunidades_id','provincias_id','municipios_id',
    ];
	
	 /**
     * Get the post that owns the comment.
     */
    public function clientes()
    {
        return $this->hasOne('App\Direcciones');
    }
	
	public function comunidades()
    {
        return $this->belongsTo('App\Comunidades');
    }
	
	public function provincias()
    {
        return $this->belongsTo('App\Provincias');
    }
	public function municipios()
    {
        return $this->belongsTo('App\Municipios');
    }
}
