<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pedidos extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'usuario_id', 'numero_pedido','estado_pago','fecha_pedido','fecha_envio',
		'fecha_actualizacion_pedido','usuario_actualizacion_id','clientes_id','descripcion_incidencia','agencias_de_transporte_id',
		'metodos_de_pago_id','direccion','total',
    ];
	
		 /**
     * Get the post that owns the comment.
     */
    public function users()
    {
        return $this->hasOne('App\Users');
    }
	
	public function agencias_de_transporte()
    {
        return $this->hasOne('App\Agencias_de_transporte');
    }
	
	public function metodos_de_pago()
    {
        return $this->hasOne('App\Metodos_de_pago');
    }
	
	public function clientes()
    {
        return $this->hasOne('App\Clientes');
    }
}
